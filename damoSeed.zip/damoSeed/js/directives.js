$scp.$directive.myPromotion = {
	template 	: 'templates/directive.myPromotion.html',
	seed 		: 'seed'
}
