//Define some directives ___________________________________________
damo.directive = {
	shoppingList : {
		templateUrl : 'templates/shoppingList.html',
		controller 	: 'controller_shopCart'
	}
	
}

