//my own library
function calculateAgeOfCaptain() {
	return 48;
}
