//Array of objects
$scp.$routing = [
	{
		url 		: '/',
		template 	: 'index.html'
	},
	{
		url 		: '/infos',
		template 	: 'templates/page2.html'
	},
	{
		url 		: '/table',
		template 	: 'templates/page3.html'
	}
];
